﻿namespace COMP2614Final
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
			this.labelSku = new System.Windows.Forms.Label();
			this.labelQuantity = new System.Windows.Forms.Label();
			this.labelSkuList = new System.Windows.Forms.Label();
			this.labelDescription = new System.Windows.Forms.Label();
			this.labelPrice = new System.Windows.Forms.Label();
			this.labelExtended = new System.Windows.Forms.Label();
			this.checkBoxTaxable = new System.Windows.Forms.CheckBox();
			this.listBoxSku = new System.Windows.Forms.ListBox();
			this.textBoxQuantity = new System.Windows.Forms.TextBox();
			this.textBoxSku = new System.Windows.Forms.TextBox();
			this.textBoxDescription = new System.Windows.Forms.TextBox();
			this.textBoxPrice = new System.Windows.Forms.TextBox();
			this.textBoxExtended = new System.Windows.Forms.TextBox();
			this.labelLegends = new System.Windows.Forms.Label();
			this.labelResults = new System.Windows.Forms.Label();
			this.buttonSave = new System.Windows.Forms.Button();
			this.labelSubTotal = new System.Windows.Forms.Label();
			this.labelGst = new System.Windows.Forms.Label();
			this.labelPst = new System.Windows.Forms.Label();
			this.labelTotal = new System.Windows.Forms.Label();
			this.labelTotalOutput = new System.Windows.Forms.Label();
			this.labelPstOutput = new System.Windows.Forms.Label();
			this.labelGstOutput = new System.Windows.Forms.Label();
			this.labelSubTotalOutput = new System.Windows.Forms.Label();
			this.buttonClose = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// labelSku
			// 
			this.labelSku.AutoSize = true;
			this.labelSku.Location = new System.Drawing.Point(173, 61);
			this.labelSku.Name = "labelSku";
			this.labelSku.Size = new System.Drawing.Size(32, 13);
			this.labelSku.TabIndex = 0;
			this.labelSku.Text = "S&KU:";
			this.labelSku.Click += new System.EventHandler(this.label1_Click);
			// 
			// labelQuantity
			// 
			this.labelQuantity.AutoSize = true;
			this.labelQuantity.Location = new System.Drawing.Point(173, 26);
			this.labelQuantity.Name = "labelQuantity";
			this.labelQuantity.Size = new System.Drawing.Size(49, 13);
			this.labelQuantity.TabIndex = 0;
			this.labelQuantity.Text = "&Quantity:";
			// 
			// labelSkuList
			// 
			this.labelSkuList.AutoSize = true;
			this.labelSkuList.Location = new System.Drawing.Point(1, 3);
			this.labelSkuList.Name = "labelSkuList";
			this.labelSkuList.Size = new System.Drawing.Size(48, 13);
			this.labelSkuList.TabIndex = 0;
			this.labelSkuList.Text = "&SKU List";
			// 
			// labelDescription
			// 
			this.labelDescription.AutoSize = true;
			this.labelDescription.Location = new System.Drawing.Point(173, 93);
			this.labelDescription.Name = "labelDescription";
			this.labelDescription.Size = new System.Drawing.Size(63, 13);
			this.labelDescription.TabIndex = 0;
			this.labelDescription.Text = "&Description:";
			// 
			// labelPrice
			// 
			this.labelPrice.AutoSize = true;
			this.labelPrice.Location = new System.Drawing.Point(173, 126);
			this.labelPrice.Name = "labelPrice";
			this.labelPrice.Size = new System.Drawing.Size(34, 13);
			this.labelPrice.TabIndex = 0;
			this.labelPrice.Text = "&Price:";
			// 
			// labelExtended
			// 
			this.labelExtended.AutoSize = true;
			this.labelExtended.Location = new System.Drawing.Point(173, 158);
			this.labelExtended.Name = "labelExtended";
			this.labelExtended.Size = new System.Drawing.Size(55, 13);
			this.labelExtended.TabIndex = 0;
			this.labelExtended.Text = "&Extended:";
			// 
			// checkBoxTaxable
			// 
			this.checkBoxTaxable.AutoSize = true;
			this.checkBoxTaxable.Location = new System.Drawing.Point(266, 194);
			this.checkBoxTaxable.Name = "checkBoxTaxable";
			this.checkBoxTaxable.Size = new System.Drawing.Size(64, 17);
			this.checkBoxTaxable.TabIndex = 7;
			this.checkBoxTaxable.Text = "&Taxable";
			this.checkBoxTaxable.UseVisualStyleBackColor = true;
			// 
			// listBoxSku
			// 
			this.listBoxSku.FormattingEnabled = true;
			this.listBoxSku.Location = new System.Drawing.Point(4, 15);
			this.listBoxSku.Name = "listBoxSku";
			this.listBoxSku.Size = new System.Drawing.Size(120, 368);
			this.listBoxSku.TabIndex = 1;
			this.listBoxSku.SelectedIndexChanged += new System.EventHandler(this.listBoxSku_SelectedIndexChanged);
			// 
			// textBoxQuantity
			// 
			this.textBoxQuantity.Location = new System.Drawing.Point(266, 23);
			this.textBoxQuantity.Name = "textBoxQuantity";
			this.textBoxQuantity.Size = new System.Drawing.Size(100, 20);
			this.textBoxQuantity.TabIndex = 2;
			this.textBoxQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxSku
			// 
			this.textBoxSku.Location = new System.Drawing.Point(266, 58);
			this.textBoxSku.Name = "textBoxSku";
			this.textBoxSku.Size = new System.Drawing.Size(138, 20);
			this.textBoxSku.TabIndex = 3;
			// 
			// textBoxDescription
			// 
			this.textBoxDescription.Location = new System.Drawing.Point(266, 91);
			this.textBoxDescription.Name = "textBoxDescription";
			this.textBoxDescription.Size = new System.Drawing.Size(223, 20);
			this.textBoxDescription.TabIndex = 4;
			// 
			// textBoxPrice
			// 
			this.textBoxPrice.Location = new System.Drawing.Point(266, 124);
			this.textBoxPrice.Name = "textBoxPrice";
			this.textBoxPrice.Size = new System.Drawing.Size(138, 20);
			this.textBoxPrice.TabIndex = 5;
			this.textBoxPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// textBoxExtended
			// 
			this.textBoxExtended.BackColor = System.Drawing.SystemColors.Window;
			this.textBoxExtended.Location = new System.Drawing.Point(266, 156);
			this.textBoxExtended.Name = "textBoxExtended";
			this.textBoxExtended.ReadOnly = true;
			this.textBoxExtended.ShortcutsEnabled = false;
			this.textBoxExtended.Size = new System.Drawing.Size(138, 20);
			this.textBoxExtended.TabIndex = 6;
			this.textBoxExtended.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
			// 
			// labelLegends
			// 
			this.labelLegends.AutoSize = true;
			this.labelLegends.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
			this.labelLegends.Location = new System.Drawing.Point(202, 261);
			this.labelLegends.Name = "labelLegends";
			this.labelLegends.Size = new System.Drawing.Size(0, 20);
			this.labelLegends.TabIndex = 14;
			// 
			// labelResults
			// 
			this.labelResults.AutoSize = true;
			this.labelResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
			this.labelResults.Location = new System.Drawing.Point(624, 26);
			this.labelResults.Name = "labelResults";
			this.labelResults.Size = new System.Drawing.Size(0, 20);
			this.labelResults.TabIndex = 15;
			this.labelResults.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// buttonSave
			// 
			this.buttonSave.Location = new System.Drawing.Point(414, 190);
			this.buttonSave.Name = "buttonSave";
			this.buttonSave.Size = new System.Drawing.Size(75, 23);
			this.buttonSave.TabIndex = 8;
			this.buttonSave.Text = "Sa&ve";
			this.buttonSave.UseVisualStyleBackColor = true;
			this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);
			// 
			// labelSubTotal
			// 
			this.labelSubTotal.AutoSize = true;
			this.labelSubTotal.Location = new System.Drawing.Point(183, 261);
			this.labelSubTotal.Name = "labelSubTotal";
			this.labelSubTotal.Size = new System.Drawing.Size(53, 13);
			this.labelSubTotal.TabIndex = 16;
			this.labelSubTotal.Text = "Sub Total";
			// 
			// labelGst
			// 
			this.labelGst.AutoSize = true;
			this.labelGst.Location = new System.Drawing.Point(203, 286);
			this.labelGst.Name = "labelGst";
			this.labelGst.Size = new System.Drawing.Size(29, 13);
			this.labelGst.TabIndex = 0;
			this.labelGst.Text = "GST";
			// 
			// labelPst
			// 
			this.labelPst.AutoSize = true;
			this.labelPst.Location = new System.Drawing.Point(200, 311);
			this.labelPst.Name = "labelPst";
			this.labelPst.Size = new System.Drawing.Size(28, 13);
			this.labelPst.TabIndex = 0;
			this.labelPst.Text = "PST";
			// 
			// labelTotal
			// 
			this.labelTotal.AutoSize = true;
			this.labelTotal.Location = new System.Drawing.Point(191, 334);
			this.labelTotal.Name = "labelTotal";
			this.labelTotal.Size = new System.Drawing.Size(31, 13);
			this.labelTotal.TabIndex = 0;
			this.labelTotal.Text = "Total";
			// 
			// labelTotalOutput
			// 
			this.labelTotalOutput.AutoSize = true;
			this.labelTotalOutput.Location = new System.Drawing.Point(263, 334);
			this.labelTotalOutput.Name = "labelTotalOutput";
			this.labelTotalOutput.Size = new System.Drawing.Size(31, 13);
			this.labelTotalOutput.TabIndex = 0;
			this.labelTotalOutput.Text = "Total";
			// 
			// labelPstOutput
			// 
			this.labelPstOutput.AutoSize = true;
			this.labelPstOutput.Location = new System.Drawing.Point(263, 311);
			this.labelPstOutput.Name = "labelPstOutput";
			this.labelPstOutput.Size = new System.Drawing.Size(28, 13);
			this.labelPstOutput.TabIndex = 0;
			this.labelPstOutput.Text = "PST";
			// 
			// labelGstOutput
			// 
			this.labelGstOutput.AutoSize = true;
			this.labelGstOutput.Location = new System.Drawing.Point(263, 286);
			this.labelGstOutput.Name = "labelGstOutput";
			this.labelGstOutput.Size = new System.Drawing.Size(29, 13);
			this.labelGstOutput.TabIndex = 0;
			this.labelGstOutput.Text = "GST";
			// 
			// labelSubTotalOutput
			// 
			this.labelSubTotalOutput.AutoSize = true;
			this.labelSubTotalOutput.Location = new System.Drawing.Point(263, 261);
			this.labelSubTotalOutput.Name = "labelSubTotalOutput";
			this.labelSubTotalOutput.Size = new System.Drawing.Size(53, 13);
			this.labelSubTotalOutput.TabIndex = 0;
			this.labelSubTotalOutput.Text = "Sub Total";
			// 
			// buttonClose
			// 
			this.buttonClose.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonClose.Location = new System.Drawing.Point(414, 350);
			this.buttonClose.Name = "buttonClose";
			this.buttonClose.Size = new System.Drawing.Size(75, 23);
			this.buttonClose.TabIndex = 9;
			this.buttonClose.Text = "&Close";
			this.buttonClose.UseVisualStyleBackColor = true;
			this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
			// 
			// MainForm
			// 
			this.AcceptButton = this.buttonSave;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.buttonClose;
			this.ClientSize = new System.Drawing.Size(567, 430);
			this.Controls.Add(this.buttonClose);
			this.Controls.Add(this.labelTotalOutput);
			this.Controls.Add(this.labelPstOutput);
			this.Controls.Add(this.labelGstOutput);
			this.Controls.Add(this.labelSubTotalOutput);
			this.Controls.Add(this.labelTotal);
			this.Controls.Add(this.labelPst);
			this.Controls.Add(this.labelGst);
			this.Controls.Add(this.labelSubTotal);
			this.Controls.Add(this.buttonSave);
			this.Controls.Add(this.labelResults);
			this.Controls.Add(this.labelLegends);
			this.Controls.Add(this.textBoxExtended);
			this.Controls.Add(this.textBoxPrice);
			this.Controls.Add(this.textBoxDescription);
			this.Controls.Add(this.textBoxSku);
			this.Controls.Add(this.textBoxQuantity);
			this.Controls.Add(this.listBoxSku);
			this.Controls.Add(this.checkBoxTaxable);
			this.Controls.Add(this.labelExtended);
			this.Controls.Add(this.labelPrice);
			this.Controls.Add(this.labelDescription);
			this.Controls.Add(this.labelSkuList);
			this.Controls.Add(this.labelQuantity);
			this.Controls.Add(this.labelSku);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "MainForm";
			this.Text = "COMP2614 Final Exam";
			this.Load += new System.EventHandler(this.MainForm_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelSku;
        private System.Windows.Forms.Label labelQuantity;
        private System.Windows.Forms.Label labelSkuList;
        private System.Windows.Forms.Label labelDescription;
        private System.Windows.Forms.Label labelPrice;
        private System.Windows.Forms.Label labelExtended;
        private System.Windows.Forms.CheckBox checkBoxTaxable;
        private System.Windows.Forms.ListBox listBoxSku;
        private System.Windows.Forms.TextBox textBoxQuantity;
        private System.Windows.Forms.TextBox textBoxSku;
        private System.Windows.Forms.TextBox textBoxDescription;
        private System.Windows.Forms.TextBox textBoxPrice;
        private System.Windows.Forms.TextBox textBoxExtended;
        private System.Windows.Forms.Label labelLegends;
        private System.Windows.Forms.Label labelResults;
        private System.Windows.Forms.Button buttonSave;
		private System.Windows.Forms.Label labelSubTotal;
		private System.Windows.Forms.Label labelGst;
		private System.Windows.Forms.Label labelPst;
		private System.Windows.Forms.Label labelTotal;
		private System.Windows.Forms.Label labelTotalOutput;
		private System.Windows.Forms.Label labelPstOutput;
		private System.Windows.Forms.Label labelGstOutput;
		private System.Windows.Forms.Label labelSubTotalOutput;
		private System.Windows.Forms.Button buttonClose;
	}
}

